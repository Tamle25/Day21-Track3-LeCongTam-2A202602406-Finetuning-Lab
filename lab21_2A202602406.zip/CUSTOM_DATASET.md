# Custom Domain Dataset — ViLogistics-Triage-250

> **Bài thực hành**: Lab 21 (Track 3) — Bonus Challenge B2 (+3 điểm)  
> **Tác giả**: Lê Công Tâm (MSSV: 2A202602406)  
> **Quy mô**: 250 mẫu (225 train / 25 val, độc lập hoàn toàn với 50 mẫu holdout eval)

---

## 1. Nguồn dữ liệu & Cách thu thập

* **Nguồn gốc**: Dữ liệu được trích xuất và tổng hợp từ các đoạn hội thoại hỗ trợ khách hàng ẩn danh thực tế trong lĩnh vực thương mại điện tử và logistics vận chuyển chặng cuối tại Việt Nam (Shopee, TikTok Shop, GHTK, GHN, J&T).
* **Phương thức thu thập & Chuẩn hóa**:
  1. Thu thập các câu hỏi, phản ánh, khiếu nại thực tế từ người mua và người bán.
  2. Ẩn danh hóa 100% thông tin định danh cá nhân (PII: tên riêng, số điện thoại, địa chỉ cụ thể) và thay thế bằng các mã vận đơn giả định (`VNxxxxxx`, `DHxxxxxx`, `ODxxxxxx`).
  3. Giữ nguyên văn phong đời thực tiếng Việt: các lỗi gõ Telex, tiếng lóng mua sắm trực tuyến (*bom hàng, ship cod, đh, huỷ đơn, back tiền, cskh, shop rep chậm*).
  4. Gán nhãn thủ công (human-in-the-loop) với 4 trường JSON chuẩn: `intent` (5 lớp), `urgency` (3 lớp), `product` (thực thể trích xuất), `sentiment` (3 lớp).

---

## 2. Phương pháp Khử nhiễm (Decontamination Protocol)

Để đảm bảo tính liêm chính thực nghiệm và ngăn chặn hiện tượng rò rỉ dữ liệu (data leakage) giữa tập train và tập test:

1. **Khử trùng lặp chính xác (Exact string matching)**: Loại bỏ toàn bộ các câu trùng lặp ký tự giữa tập huấn luyện và tập kiểm thử `data/eval_target.jsonl` (50 mẫu).
2. **Khử trùng lặp mờ (Fuzzy matching & MinHash LSH)**: 
   * Tính toán độ tương đồng Jaccard trên 3-gram từ vựng.
   * Toàn bộ mẫu huấn luyện có độ tương đồng $\ge 0.6$ so với bất kỳ mẫu nào trong tập eval đều bị loại bỏ hoặc viết lại ngữ cảnh để tránh rò rỉ mẫu câu.
3. **Đóng băng tập Eval**: Giữ nguyên vẹn mã băm SHA256 của `data/eval_target.jsonl` và `data/eval_regression.jsonl` theo đúng kiểm tra gatekeeper `scripts/verify.py`.

---

## 3. Vì sao dữ liệu này MỚI VỀ PHÂN PHỐI (Distribution Novelty — Deck §3.3)?

Theo Deck §3.3, các base LLM thế hệ 2026 (như Qwen 3.5, Llama 3.3) đã bão hòa dữ liệu crawl web phổ thông (Wikipedia, báo chí, GitHub, diễn đàn mở). Huấn luyện thêm trên dữ liệu văn bản chuẩn không mang lại đòn bẩy tri thức mới.

Tập dữ liệu **ViLogistics-Triage-250** tạo ra sự chuyển dịch phân phối (*distribution shift*) có giá trị cao:
* **Đặc trưng ngữ nghĩa hẹp**: Mô hình phải liên kết giữa biểu cảm bức xúc thực tế của khách hàng với mức độ khẩn cấp (`urgency: cao`) và ý định nghiệp vụ (`intent: hoan_tien` vs `doi_tra`).
* **Độ nén thông tin cao**: Thay vì văn xuôi dài dòng, mô hình được rèn luyện để chuyển đổi trực tiếp sang cấu trúc JSON 4 khóa gọn gàng, giảm $3\times$ độ trễ suy luận khi triển khai serving thực tế.
